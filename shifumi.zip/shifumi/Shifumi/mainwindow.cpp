#include "mainwindow.h"
#include "ui_mainwindow.h"

using namespace std ;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow), port(3490)
{
    ui->setupUi(this);
    s = new StreamSocket(port);

}

MainWindow::~MainWindow()
{
    delete ui;
}

bool MainWindow::checkPlayersConnected() {
    // Envoyer une requête au serveur pour vérifier l'état des connexions
    string request = "CHECK_PLAYERS";
    int res = s->send(request);
    if (res <= 0) {
        ui->resultLabel->setText("Erreur lors de la vérification des joueurs !");
        return false;
    }

    // Lire la réponse du serveur (par exemple "OK" si les deux joueurs sont connectés)
    string response;
    res = s->read(response);
    if (res <= 0) {
        ui->resultLabel->setText("Erreur de lecture de la réponse du serveur !");
        return false;
    }

    // Si le serveur répond "OK", cela signifie que les deux joueurs sont connectés
    if (response == "OK") {
        return true;
    } else {
        return false;
    }
}

void MainWindow::on_GAME_clicked()
{
    // Vérifie si le choix a été effectué
    string choice = ui->CHOIX->currentText().toStdString();

    if (choice.empty()) {
        ui->resultLabel->setText("Choix invalide !");
        return;
    }

    // Vérifie si les deux joueurs sont connectés avant de commencer la partie
    bool playersReady = checkPlayersConnected();
    if (!playersReady) {
        ui->resultLabel->setText("Les deux joueurs ne sont pas encore connectés !");
        return;
    }

    // Envoie le choix du joueur au serveur
    int res = s->send(choice);
    if (res <= 0) {
        ui->resultLabel->setText("Erreur d'envoi du choix au serveur !");
        return;
    }

    ui->resultLabel->setText("Choix envoyé au serveur. Attente du résultat...");

    // Attente du résultat du serveur
    string result;
    res = s->read(result);  // Lit le résultat du serveur
    if (res <= 0) {
        ui->resultLabel->setText("Erreur de lecture du résultat !");
        return;
    }

    // Affiche le résultat reçu du serveur
    ui->resultLabel->setText(QString::fromStdString(result));
}



void MainWindow::on_CHOIX_currentTextChanged(const QString &arg1)
{
    s->send(arg1.toStdString()) ;
}

StreamSocket *MainWindow::getS() const
{
    return s;
}

void MainWindow::on_RESU_clicked()
{
        string result;
        int res = s->read(result);
        if (res <= 0) {
                ui->resultLabel->setText("Erreur de lecture du résultat du serveur !");
                return;
        }
    ui->resultLabel->setText(QString::fromStdString(result));
}

