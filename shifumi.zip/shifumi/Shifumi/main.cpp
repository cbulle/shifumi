#include "mainwindow.h"
#include <iostream>
#include "socket.h"
#include <QApplication>

using namespace std;
using namespace stdsock;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    MainWindow w;
    w.show();

    MainWindow w2;
    w2.show();

    int e1 = w.getS()->connect();
    if (e1 == -1) {
        perror("Erreur de connexion pour w");
        std::cout << strerror(errno) << std::endl;
    } else {
        cout << "Client 1 connecté à : " << w.getS()->getIP() << ":" << w.getS()->getPort() << endl;
    }

    int e2 = w2.getS()->connect();
    if (e2 == -1) {
        perror("Erreur de connexion pour w2");
        std::cout << strerror(errno) << std::endl;
    } else {
        cout << "Client 2 connecté à : " << w2.getS()->getIP() << ":" << w2.getS()->getPort() << endl;
    }

    string msg1, msg2;



    if (msg1.size() == 0) {
        perror("Pas de message reçu du client 1");
    } else {
        cout << "Message client 1 : " << msg1 << endl;
    }

    if (msg2.size() == 0) {
        perror("Pas de message reçu du client 2");
    } else {
        cout << "Message client 2 : " << msg2 << endl;
    }



    return a.exec();
}
