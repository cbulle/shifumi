#include <iostream>
#include <thread>
#include <csignal>
#include <ctime>
#include <clocale>
#include <cstring>
#include "socket.h"

using namespace std;
using namespace stdsock;

// Fonction pour déterminer le gagnant
string determineWinner(const string& player1, const string& player2) {
    if (player1 == player2)
        return "Égalité!";
    if ((player1 == "Pierre" && player2 == "Ciseaux") ||
        (player1 == "Ciseaux" && player2 == "Papier") ||
        (player1 == "Papier" && player2 == "Pierre"))
        return "Joueur 1 gagne!";
    else
        return "Joueur 2 gagne!";
}

void handleGame(StreamSocket* client1, StreamSocket* client2) {
    string choice1, choice2;

    // Vérifie si les deux clients sont connectés et prêts
    if (!client1->valid() || !client2->valid()) {
        cout << "Erreur de connexion avec un des joueurs." << endl;
        return;
    }

    // Lecture des choix des joueurs
    if (client1->read(choice1) <= 0) {
        cout << "Erreur de lecture du choix du joueur 1!" << endl;
        delete client1;
        delete client2;
        return;
    }

    if (client2->read(choice2) <= 0) {
        cout << "Erreur de lecture du choix du joueur 2!" << endl;
        delete client1;
        delete client2;
        return;
    }

    cout << "Joueur 1 a choisi : " << choice1 << endl;
    cout << "Joueur 2 a choisi : " << choice2 << endl;

    // Déterminer le gagnant
    string result = determineWinner(choice1, choice2);

    // Envoi du résultat aux deux joueurs
    if (client1->send(result.c_str(), result.size(), 0) <= 0) {
        cout << "Erreur lors de l'envoi du résultat au joueur 1!" << endl;
    }

    if (client2->send(result.c_str(), result.size(), 0) <= 0) {
        cout << "Erreur lors de l'envoi du résultat au joueur 2!" << endl;
    }

    // Supprimer les clients après la partie
    delete client1;
    delete client2;
    cout << "Les joueurs sont déconnectés." << endl;
}

// Fonction pour vérifier si les joueurs sont connectés
string checkPlayers(StreamSocket* client1, StreamSocket* client2) {
    if (client1->valid() && client2->valid()) {
        return "OK";  // Les deux joueurs sont connectés
    } else {
        return "ERROR";  // Un ou les deux joueurs ne sont pas connectés
    }
}


int main() {
    ConnectionPoint* server = new ConnectionPoint(3490);
    int err = server->init();
    if (err != 0) {
        cout << "Erreur lors de l'initialisation du serveur : " << strerror(err) << endl;
        delete server;
        exit(err);
    }

    cout << "Serveur démarré sur " << server->getIP() << ":" << server->getPort() << endl;

    while (true) {
        StreamSocket* client1 = server->accept();
        if (!client1->valid()) {
            cout << "Erreur lors de la connexion avec le client 1." << endl;
            continue;
        }
        cout << "Joueur 1 connecté : " << client1->getIP() << ":" << client1->getPort() << endl;

        StreamSocket* client2 = server->accept();
        if (!client2->valid()) {
            cout << "Erreur lors de la connexion avec le client 2." << endl;
            delete client1;  // Libérer la mémoire du premier client
            continue;
        }
        cout << "Joueur 2 connecté : " << client2->getIP() << ":" << client2->getPort() << endl;

        thread gameThread(handleGame, client1, client2);
        gameThread.detach();
    }

    delete server;
    return 0;
}
